    </TD>
  </TR>
  <TR>
    <TD colspan=9 height=5 bgcolor="#8EBBE6"><img src="images/space.gif"></TD>
  </TR>
  <TR>
    <TD colspan=9 height=1 bgcolor="#FFFFFF"><img src="images/space.gif"></TD>
  </TR>
<!--links for text browsers starts-->
	<noscript>  
		<TR>
		  <TD colspan=9 height=1 bgcolor="#F5F5F5" align=center class=body><A href="xmec.html" class=link>XMEC</A> | <A href="college.html" class=link>College</A> | <A href="university.html" class=link>University</A> 
		  </TD>
		</TR>
		<TR>
		  <TD colspan=9 height=1 bgcolor="#FFFFFF" align=center><img src="images/space.gif"></TD>
		</TR>
	</noscript>
<!--links for text browsers ends-->
  <TR>
    <TD colspan=9 height=10 bgcolor="#0958A3"><img src="images/space.gif"></TD>
  </TR>
  <TR>
    <TD colspan=9 align=center valign=center height=20 class=footer>� XMEC, All rights reserved. Best viewed in 800x600 resolution. / <A href="disc.html" class=news>Disclaimer</A> / <A href="sitemap.html" class=news>Sitemap</A> /</TD>
  </TR>
 </TABLE>
<map name="XMEC">
	<area shape="rect" coords="13,5,125,30" href="index.html">
</map>
</BODY>
</HTML>
