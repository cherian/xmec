<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> Letters >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD valign=top><P class=body><strong>MS - Monetary Concerns</strong></P><BR>

<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><img src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><img src="images/tableleft.gif"></TD>
	<TD width=433 class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>Expense Chart</strong>
<HR width=433 color=#DDDDDD>
<P class=body>In this section, we would like to give an idea about the expenses involved in the application process and this can determine the number of schools one can apply for.</P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#DDDDDD" width=290>
	<P class=body><strong>Details</strong>
	<UL><LI class=body>Applying for transcripts from the University</LI>
	<LI class=body>Application fee for the US Schools</LI>
	<LI class=body>Miscellaneous Expenses (Mail, Courier)</LI>
	<LI class=body>GRE/ TOEFL</LI>
	</UL></P>
</TD>
<TD bgcolor="#DDDDDD" width=150>
	<P class=body><strong>Expense</strong>
	<UL><LI class=body>Rs. 2000</LI>
	<LI class=body>Rs. 2500 ($50)</LI>
	<LI class=body>Rs. 500</LI>
	<LI class=body>Rs. 10,000($200)</LI>
	</UL></P>
</TD>
</TR><TR>
<TD bgcolor="#DDDDDD" width=290>
	<P class=body>If one plans to apply in <strong>N</strong> schools, the total expense will be around</P>
</TD>
<TD bgcolor="#DDDDDD" width=150>
	<P class=body>Rs. 10000 + 5000 x <strong>N</strong></P>
</TD>
</TR>
<TR><TD colspan=2><P class=body>The best recommendation will be to apply in 4-5 schools (i.e., N = 4 or 5). Our recommendation for a selection based on school ranking is as follows.</P>
<P class=body>Make sure to add at least one-maybe two schools in the range of 50-100 ranking, so that one is almost sure of admission.</P>
<P class=body>Then select 1-2 schools that one is really interested in, those in the ranking of 25-50 (most state universities fall in this category).</P>
<P class=body>Lastly, depending on whether one gets a very good GRE score, apply to one of those places in the top league (1-20) like MIT, Stanford, Berkeley, Caltech and so on.</P>
<P class=body>If one looks at the previous years GRE/TOEFL scores, one gets an idea about the admission requirements. Please feel free to contact us at <A href="higherstudies.html" class=link>Higher Studies@XMEC</A> especially regarding school selection and we can give one more pointers.</P></TD></TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><img src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><img src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

