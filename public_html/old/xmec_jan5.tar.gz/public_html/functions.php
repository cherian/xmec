<?
function renderLoginBox()
{
	global $PHP_SELF;
	$user = XMEC::getUser();
	if (! $user->isLoggedIn()) {	
?>
<TABLE cellSpacing=2 height=80 cellPadding=0 border=0>
<form name=frmlogin method=POST action=login.php>
<input type=hidden name=xgetpage value=<?=$PHP_SELF?>>
<input type=hidden name=action value=login>
  <TR>
  	<TD colspan=3 align=center height=25><img src="images/loginhead.gif" width=140 height=16></TD>
  </TR>
  <TR>
  	<TD><img src="images/userid.gif"></TD>
  	<TD><INPUT name=rollno type=text class=box size=10></TD>
  </TR>
  <TR>
  	<TD><img src="images/password.gif" width=56 height=13></TD>
  	<TD><INPUT name=passwd type=password class=box size=10></TD>
  	<TD><INPUT name=bttnlogin type=image src="images/go.gif" border=0 width=15 height=15></TD>
  </TR>
<TR>
	<P><A class=link HREF="loginerror.php">Forgot Password</A> || <A class=link HREF="nologin.php">No Login</A></P>
</TR>
</form> 
</TABLE>
<?
	}
}
?>
