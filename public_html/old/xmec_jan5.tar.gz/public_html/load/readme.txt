Anyform Version 1. By www.virtualthoughts.co.uk

The upload function in this PHP script is used in many of the PHP upload scripts written
by Virtual Thoughts. It is offered here free, in the hope you find it useful and without
any warranty what so ever. If you chose to use it, it is entirely at your risk.

There are four files included in the zip (plus this readme.txt)

anyformv1.php is the upload form processing script; all editing details are included, together
with notes on what the script is doing. 
thumbnail.php is the auto-thumbnail creation script, see script for details (No ours, by why re-invent the wheel.)
vtupload.htm is a "loud" demo upload form, the script will process anyform you point to in the 
<form> tag.
vt.css is a custom style sheet for you to mess around with.

INSTALL:

The default installation is all the files in the same directory, the directory must have read
and write permissions. chmod 777 should work on all unix based servers should you get Permission denied
errors. The files should be ok with the default permissions.

With a little bit of PHP knowledge it would be very easy to copy and paste the upload script into
any form processing script, If you would like us to do this form you, we have a minimum �10 fee.

Due to the amount of spam email, please use the Virtual Thoughts helpdesk or forum for any comments
or queries and general feedback.

Good Luck

The Virtual Thoughts Team

Please remember virtual thoughts offer web hosting for PHP sites from as little as �18/$30 per year.
