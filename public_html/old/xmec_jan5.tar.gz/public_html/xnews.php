<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >></B> XMEC</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top><BR>
  	<img src="images/dot.gif">&nbsp;&nbsp;<A class=link href="xnews.php#news15">The XMEC Hyderabad Chapter meet on January 26<sup>th</sup>, 2003...</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<A class=link href="xnews.php#news14">XMECian on BBC MasterMind India Quiz....</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<A class=link href="xnews.php#news13">The XMEC Chennai Chapter meet on December 8<sup>th</sup>, 2002...</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<A class=link href="xnews.php#news12">The USA East Coast Chapter meet on September 21<sup>st</sup>, 2002...</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<A class=link href="xnews.php#news11">The 10<sup>th</sup> Batch have become XMECians...</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<A class=link href="xnews.php#news10">Vinitha Suresh bags prestigious Innovator Asia Award...</A><BR><BR>
<img src="images/dot.gif">&nbsp;&nbsp;<A class=link href="xnews.php#news9">Product designed by an XMECian bags award...</A><BR><BR>
<BR><BR>
<IMG src="images/pen.gif"><A class=link href="addnews.php">Post a XMEC News items in the XMEC site ?</A>
<BR><BR><BR>

<HR width=100% color="#DDDDDD">
<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<A class=link name="news15">The XMEC Hyderabad Chapter meet on January 26<sup>th</sup>, 2003....</A> <BR>The first ever meet of the Hyderabad Chapter of XMEC will be held on January 26<sup>th</sup>, 2003. This would be the first chapter get together in the New Year. All XMECians are invited to take part in this get together. Interested XMECians are reqested to confirm their presence by mailing to <A class=link href="mailto:xmec-hyderabad-owner@yahoogroups.com">Coordinator, XMEC Hyderabad Chapter</A><A href="xnews.php"><img src="images/top.gif" border=0 align=right></A> </P><BR>
<HR width=100% color="#DDDDDD">
<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<A name="news14">XMECian on BBC MasterMind India Quiz....</A> <BR>Alphus Pathrose has reached the Semifinal round of the popular <strong>MasterMind India </strong> aired on the BBC Channel. The Semifinal episode will be aired at 10pm, Thursday December 19<sup>th</sup>, 2002 on the<strong> BBC World Channel</strong>. There will be repeat telecasts at 10am and 10pm on Sunday December 19<sup>th</sup>, 2002. Mastermind India is the indian version of the ever popular Mastermind Quiz show. The show is hosted by Sudhartha Basu.<BR>Alphus Pathrose did his Engineering in Electronics and hails from the 5th Batch of MEC. Alphus pursues a career in business in Kerala.<A href="xnews.php"><img src="images/top.gif" border=0 align=right></A> </P><BR>
<HR width=100% color="#DDDDDD">
<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<A name="news13">The XMEC Chennai Chapter meet on December 8<sup>th</sup>, 2002...</A> <BR>XMECians of the Chennai Chapter got together on December 8<sup>th</sup> 2002 at the <strong>MGM Quality Inn Beach resort, East Coast Road, Muttukad, Chennai</strong>. The Chennai chapter has grown to a strength of 66, proudly claiming to be the first XMEC Chapter in a metropolitan city in India. Apart from nomination the office bearers for the next financial year and other serious discussion, the get together was an occassion for fun and frolic. Details of the meeting can be found in the <A href="chapters.php" class=link >Chapter Reports</A>. Minutes of the meeting are available on the <A href="/phorum/list.php" class=link >Discussion Boards</A><BR><A href="xnews.php"><img src="images/top.gif" border=0 align=right></A> </P><BR>
<HR width=100% color="#DDDDDD">
<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<A name="news12">The USA East Coast Chapter meet on September 21<sup>st</sup>, 2002...</A> <BR>XMECians of the East Coast Chapter met on September 21<sup>st</sup> 2002 at the sprawling Johnson's Park in New Jersey. Thirty one members with kith and kin attended this year's meet. Apart from the celebrations, the XMECians discussed on ways and means to help new alumni coming to that part of the world. One can contact them at <A href="mailto:xmec_east@yahoogroups.com"class=link >xmec_east@yahoogroups.com</A>. XMECians can find a more detailed report in the <A href="chapters.php" class=link >Chapter Activities </A><BR><A href="xnews.php"><img src="images/top.gif" border=0 align=right></A> </P><BR>
<HR width=100% color="#DDDDDD">
<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<A name="news11">The 10<sup>th</sup> Batch have become XMECians...</A> <BR>Students of the 1998 - 2002 Batch have formally joined  XMEC during the later half of September 2002. Many for them have been placed in companies like Cognizant Technology Solutions, Larsen & Turbro, Paxonet Communications, Infosys Technologies Ltd, Siemens Information Systems, Poornam etc.  <BR><A href="xnews.php"><img src="images/top.gif" border=0 align=right></A> </P><BR>
<HR width=100% color="#DDDDDD">
<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<A name="news10">Vinitha Suresh bags prestigious Innovator Asia Award. </A> <BR>Vinitha Suresh was adjudged Innovator Asia by the prestigious EDN Asia Magazine. Vinitha works for Paxonet Systems in the field of IC design. Vinitha is part of the first breed of engineers who passed out of Model Engineering College. She did her Electronics Engineering during the period 1989-93. You can refer to the <A href="http://www.ednasia.com/EDNA/article.php?sid=201097" class=link >EDN news</A> item for details. <BR><A href="xnews.php"><img src="images/top.gif" border=0 align=right></A> </P><BR>
<HR width=100% color="#DDDDDD">
<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<A name="news9">Product designed by an XMECian bags award. </A> <BR>Shahnavas M S (EE 93-97) has bagged the award for Best Design in the Steel Furniture Design Competition. Shahnavas's Design represented from Featherlite Products Ltd., has been  installed in MG Road ( Between Queens Road and Kumble Circle ) for public reactions. Shahnavas did his Masters in Design from the Indian Institute of Science. He works for GE Power Controls. <BR><A href="xnews.php"><img src="images/top.gif" border=0 align=right></A> </P><BR>
<HR width=100% color="#DDDDDD">

</P><BR>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

