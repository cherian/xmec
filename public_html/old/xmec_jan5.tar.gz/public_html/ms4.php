<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> Letters >></B> Post Graduation in the USA</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<P class=body><strong>MS - Selection of Schools</strong>
			<P class=body>There are lots of factors that have to be under consideration when one selects the schools. This can be coined as one of the major steps in the Application process. People cannot afford to apply in all schools they know since it is going to cost a huge amount of money. So based on some criteria, one has to select the limited number of schools one intends to apply. The main criteria for selecting the schools are:<BR>
			<UL><LI class=body><strong>General Ranking of the School </strong>(Visit <a class=link href="http://www.usnews.com/">www.usnews.com</font></a>)</LI><BR>
			<LI class=body><strong>Ranking of the school in the major that one is interested
              </strong>in. Even if the general ranking of the school is good, there is a chance that the ranking of the school in the specialization one is interested in, may not be worthwhile. So it is always advised to check the ranking of the school in the specialization one is looking at.</LI><BR>
			<LI class=body><strong>Funding in the School for that particular specialization.</strong> </LI><BR>
			<LI class=body><strong>Try to talk (email) to the present students and alumni </strong>to get a rough idea about the same.</LI><BR>
			<LI class=body><strong>See whether the school is a state school or a private school</strong>. This is a major factor that decides the fee structure of the school.</LI><BR>
			<LI class=body><strong>Location of the school.</strong> It is always a wise thing to join a school around which there are lot of industries and companies especially in one�s area of specialization.</p><BR>
			<LI class=body><strong>Faculty especially the number and the recognition and appreciation each of them has are also very important.</strong> Check whether they have enough resources, labs etc in one�s area of specialization. Browsing through the school/department/lab website will be the major source of information. Also please check with the Indian Student Association or Graduate Student Association to get more info.</LI><BR>
			<LI class=body><strong>It is preferable to join some school where one has friends or one�s old college mates</strong>. It may be a good idea to join some school if one have some relatives nearby.</LI>
			</UL>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

