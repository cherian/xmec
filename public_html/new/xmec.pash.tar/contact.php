<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<CENTER><BR>
<TABLE cellSpacing=0 cellPadding=1 width=80% border=0>
  <TR>
  	<TD width=100% height=40 class=head><B>XMEC >></B>Contacts</TD>
  </TR>
  <TR>
  	<TD width=100% valign=top>
  
<!-- Box start -->
<TABLE cellSpacing=0 cellPadding=0 border=0 width="100%">
<TBODY>
  <TR>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
        <TD align=left background=images/tb_top.gif height=4><IMG height=4 src="images/tb_left_topt.gif" width=8></TD>
        <TD align=right background=images/tb_top.gif height=4><IMG height=4 src="images/tb_right_topt.gif" width=8></TD>
        <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>    </TR>
    <TR>
    <TD vAlign=top width=4 background=images/tb_left.gif height="50%"><IMG height=6 src="images/tb_left_topb.gif" width=3></TD>
    <TD colSpan=2 rowSpan=2>

<!--Content Starts-->
	<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>College</strong></A>
	<HR color="#dddddd" height=1 width=99%>
	<TABLE width=100%>
	<TR>
		<TD width=280 class=body>Principal</TD>
		<TD><A href="mailto:jyothijohn@mec.ac.in"class=link>Prof. Jyothi John</A></TD>
	</TR>
	<TR>
		<TD width=280 bgcolor=#DDDDDD class=body>Head of Dept, Computer Engg.</TD>
		<TD bgcolor=#DDDDDD><A href="mailto:jyothijohn@mec.ac.in"class=link> Prof. Jyothi John</A></TD>
	</TR>
	<TR>
		<TD width=280 class=body>Head of Dept, Electronics & Biomedical Engg.</TD>
		<TD class=body>Ms. Jessy John</TD>
	</TR>
	<TR>
		<TD width=280 bgcolor=#DDDDDD class=body>Head of Dept, Electronics Engg.</TD>
		<TD bgcolor=#DDDDDD><A href="mailto:jaya@mec.ac.in"class=link> Ms. Jayashree M </A></TD>
	</TR>
	</TABLE></P>
<!--Content Ends-->
</TD>
    <TD vAlign=top width=4 background=images/tb_right.gif height="50%"><IMG height=6 src="images/tb_right_topb.gif" width=3></TD>
  </TR>
  <TR>
    <TD vAlign=bottom width=4 background=images/tb_left.gif height="50%"><IMG height=6 src="images/tb_left_bottomb.gif" width=3></TD>
    <TD vAlign=bottom width=4 background=images/tb_right.gif height="50%"><IMG height=6 src="images/tb_right_bottomb.gif" width=3></TD>
  </TR>
    <TR>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
    <TD align=left background=images/tb_bottom.gif height=4><IMG height=4 src="images/tb_left_bottomt.gif" width=8></TD>
    <TD align=right background=images/tb_bottom.gif height=4><IMG height=4 src="images/tb_right_bottomt.gif" width=8></TD>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
  </TR>
  </TBODY>
</TABLE>
<!--Box Ends-->


<BR><BR>

<!----Placements Table---->

<!--Box starts -->
<TABLE cellSpacing=0 cellPadding=0 border=0 width="100%">
<TBODY>
  <TR>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
        <TD align=left background=images/tb_top.gif height=4><IMG height=4 src="images/tb_left_topt.gif" width=8></TD>
        <TD align=right background=images/tb_top.gif height=4><IMG height=4 src="images/tb_right_topt.gif" width=8></TD>
        <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>    </TR>
    <TR>
    <TD vAlign=top width=4 background=images/tb_left.gif height="50%"><IMG height=6 src="images/tb_left_topb.gif" width=3></TD>
    <TD colSpan=2 rowSpan=2>

<!--Content Starts-->
	<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>Placements</strong>
		<HR color="#dddddd" height=1 width=100%>
	<TABLE width=100%>
		<TR>
			<TD width=280 class=body>&nbsp;&nbsp;Staff in Charge</TD>
			<TD><A href="mailto:jaya@mec.ac.in"class=link> Ms. Jayashree M </A></TD>
		</TR>
		<TR>
			<TD width=280 bgcolor=#DDDDDD class=body>&nbsp;&nbsp;Student Coordinators </TD>
			<TD bgcolor=#DDDDDD><A href="mailto:pc@mec.ac.in"class=link>pc@mec.ac.in</A></TD>
		</TR></TABLE></P>
<!--Content Ends-->

</TD>
    <TD vAlign=top width=4 background=images/tb_right.gif height="50%"><IMG height=6 src="images/tb_right_topb.gif" width=3></TD>
  </TR>
  <TR>
    <TD vAlign=bottom width=4 background=images/tb_left.gif height="50%"><IMG height=6 src="images/tb_left_bottomb.gif" width=3></TD>
    <TD vAlign=bottom width=4 background=images/tb_right.gif height="50%"><IMG height=6 src="images/tb_right_bottomb.gif" width=3></TD>
  </TR>
    <TR>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
    <TD align=left background=images/tb_bottom.gif height=4><IMG height=4 src="images/tb_left_bottomt.gif" width=8></TD>
    <TD align=right background=images/tb_bottom.gif height=4><IMG height=4 src="images/tb_right_bottomt.gif" width=8></TD>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
  </TR>
  </TBODY>
</TABLE>
  <!--Box ends -->

<BR><BR>

<!----Alumni Table---->

<!-- Box start -->
<TABLE cellSpacing=0 cellPadding=0 border=0 width="100%">
<TBODY>
  <TR>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
        <TD align=left background=images/tb_top.gif height=4><IMG height=4 src="images/tb_left_topt.gif" width=8></TD>
        <TD align=right background=images/tb_top.gif height=4><IMG height=4 src="images/tb_right_topt.gif" width=8></TD>
        <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>    </TR>
    <TR>
    <TD vAlign=top width=4 background=images/tb_left.gif height="50%"><IMG height=6 src="images/tb_left_topb.gif" width=3></TD>
    <TD colSpan=2 rowSpan=2>

<!--Content Starts-->
		<P class=body><img src="images/dot1.gif">&nbsp;&nbsp;<strong>Alumni</strong>
		<HR color="#dddddd" height=1 width=99%>
	<TABLE width=100%>
		<TR>
			<TD width=280 class=body>Executive Committee President</TD>
			<TD><A href="search.php?&name=vidhiprasad+k+v&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Vidhi Prasad</A></TD>
		</TR>
		<TR>
			<TD bgcolor=#DDDDDD class=body>Bangalore Chapter President</TD>
			<TD bgcolor=#DDDDDD><A href="search.php?&name=manu++sreenivasan&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Manu Sreenivasan</A></TD>
		</TR>
		<TR>
			<TD class=body>Chennai Chapter President</TD>
			<TD><A href="search.php?&name=prinu+shaan+nazeem&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Prinu Shaan Nazeem</A></TD>
		</TR>
		<TR>
			<TD bgcolor=#DDDDDD class=body>US East Coast Chapter Coordinator</TD>
			<TD bgcolor=#DDDDDD><A href="search.php?&name=joby++babu&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Joby Babu</A></TD>
		</TR>
		<TR>
			<TD class=body>US West Coast Chapter Coordinator</TD>
			<TD><A href="search.php?&name=faisal+p+a&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Faisal P A</A></TD>
		</TR>
		<TR>
			<TD bgcolor=#DDDDDD class=body>XMEC YahooGroups Moderator</TD>
			<TD bgcolor=#DDDDDD><A href="search.php?&name=vyas+mohan+thottathil&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Vyas Mohan Thottathil</A></TD>
		</TR>
		<TR>
			<TD class=body>XMEC Webmasters</TD>
			<TD><A href="mailto:webmasters@xmec.net" class=link>Webmasters</A></TD>
		</TR>
		</TABLE>
		</P>
<!--Content Ends-->
</TD>
    <TD vAlign=top width=4 background=images/tb_right.gif height="50%"><IMG height=6 src="images/tb_right_topb.gif" width=3></TD>
  </TR>
  <TR>
    <TD vAlign=bottom width=4 background=images/tb_left.gif height="50%"><IMG height=6 src="images/tb_left_bottomb.gif" width=3></TD>
    <TD vAlign=bottom width=4 background=images/tb_right.gif height="50%"><IMG height=6 src="images/tb_right_bottomb.gif" width=3></TD>
  </TR>
    <TR>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
    <TD align=left background=images/tb_bottom.gif height=4><IMG height=4 src="images/tb_left_bottomt.gif" width=8></TD>
    <TD align=right background=images/tb_bottom.gif height=4><IMG height=4 src="images/tb_right_bottomt.gif" width=8></TD>
    <TD width=4 height=4><IMG height=4 src="images/corner.gif" width=4></TD>
  </TR>
  </TBODY>
</TABLE>
  <!--Box ends -->

</TABLE>
<BR></CENTER>
<!--center ends-->
<?php
$secure_page=1;
include 'footer.php';
?>
