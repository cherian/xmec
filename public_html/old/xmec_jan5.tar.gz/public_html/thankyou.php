<?php
$secure_page=0;
include 'header.php';
?>
<TABLE BGCOLOR="white" align=left border=0 cellPadding=0 cellSpacing=0 width="615" height="100%">
<TR>
<TD valign=center align=center width=615><img src="images/thanks.jpg"><BR><BR>
<font face=arial color="#FF0000" size=2><strong>Thanks for submitting the Query. We will get back to you soon. </strong></font>

</TD>
<TR>
<TD align=center>
<A href="javascript:history.back();"><img src="images/back.gif" border=0></A>
</TD></TR>
</TR></TABLE> 

<?php
include 'footer.php';
?>