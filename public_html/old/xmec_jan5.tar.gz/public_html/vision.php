<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>Vision >></B></TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<P class=body>We <A class=link href="mailto:moderator@xmec.net">XMECians</A> believe that there is a lot that we can do for the college and the world around us. XMEC pledges to be a beacon of light for the prot�g� from our Alma mater, helping them to choose careers, offering guidance, sharing experiences and valuable information regarding new openings� </P>
<P class=body>XMEC also realizes its responsibilities to the society. XMECians believe that each one of us can play a role in bridging the gap. XMEC has a comprehensive ground plan for social service�. </P>
<P class=body>The vision of XMEC is to transform MEC into an institute of laudable recognition in all fields in a span of ten years. The transformation would take place in a phased manner, in areas of academics, infrastructure, sports, arts and placements. </P>
<P class=body>In ten years, MEC would have the best talents in the national academic sphere to adorn its classrooms. MEC would be venue to conferences of repute, on relevant topics. The staff and students of MEC would publish at least twenty papers every year. </P>
<P class=body>MEC would have state-of-the-art infrastructure in the fields of Computers, Electronics and Bio Medical Engineering. In ten years, MEC would have in its ranks one of the best teams among engineering colleges in India in football, basketball, volleyball, and cricket. </P>
<P class=body>Within a decade, the MEC arts festival would feature among the elite list of the most visited and participated among all the engineering colleges in India. </P>
<P class=body>An efficient placement scheme would be in place, which would guide all the students towards a fruitful career and provide them with all the assistance so that they actually achieve it. </P>
<P class=body><I><strong>The value that binds together XMEC is 'EXCELLENCE'. </strong></I></P><BR>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

