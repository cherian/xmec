<?php
$secure_page=0;
include 'header.php';
?>

<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=100% border=1>
  <TR>
  	<TD width=90% height=40 class=head><B>Login Help >></B> Request Password Change</TD>
  </TR>
  <TR>
  	<TD valign=top width=445 class=body><BR><BR><P class=body>Please enter the required details. The XMEC Webmasters will send the changed password to your Personal E-mail address. </strong></P>

<script Language="JavaScript" src="jslibxmec.js">
</script>
<script language="javascript">

function check()
{

  if (false == validate())
  {
     
   }
   else
   document.loginerror.submit();
   
 }   
function validate()
{
	if (document.loginerror.Batch.value == ""){ 
	alert("Please Select your Batch");
	return false;
	}
		
	if (document.loginerror.Rollno.value == ""){ 
	alert("Please record your College Roll Number ");
	return false;
	}
	if(!CheckEmailStr(document.loginerror.email.value )){
//	alert("Please verify Personel Email");
	return false;
	}
	if((document.loginerror.Dob.value == "" ) ||((false == CheckDate(document.loginerror.Dob.value))) || ((IsDateGreaterToday(document.loginerror.Dob.value)))){
			alert("Please Enter the correct Date of Birth. Use dd/mm/yyyy format");
			return false;
		}
		return true;
	}

</script>
      &nbsp;
<form name="loginerror" method="post"
action="/server-scripts/formmail/FormMail.pl">
<input type=hidden name="recipient" value="webmasters@xmec.addr.com">
<INPUT TYPE=hidden NAME="subject" VALUE="[xmec.net] Password Reset">
<input type=hidden name="redirect" value="http://www.xmec.net/thankyou.php">


<TABLE BORDER=1 cellpadding=5 cellspacing=0 bordercolor="#dddddd" WIDTH=100%>
<TR>
<TD width=40% class=body><B>Batch</B></TD>
<TD width=60% colspan=2><SELECT NAME="Batch" width="250" class=cbox>
							<OPTION value="" selected>Select One</OPTION>
							<OPTION value="batch1">1st Batch (89-93)</OPTION>
							<OPTION value="batch2">2nd Batch (90-94)</OPTION>
							<OPTION value="batch3">3rd Batch (91-95)</OPTION>
							<OPTION value="batch4">4th Batch (92-96)</OPTION>
							<OPTION value="batch5">5th Batch (93-97)</OPTION>
							<OPTION value="batch6">6th Batch (94-98)</OPTION>
							<OPTION value="batch7">7th Batch (95-99)</OPTION>
							<OPTION value="batch8">8th Batch (96-00)</OPTION>
							<OPTION value="batch9">9th Batch (97-01)</OPTION>
							<OPTION value="batch10">10th Batch (98-02)</OPTION>
							<OPTION value="batch11">11th Batch (99-03)</OPTION>
							</SELECT></TD>
</TR>
<TR>
<TD width=40% class=body><B>Roll No</B></TD>
<TD width=60% colspan=2><INPUT NAME="Rollno" SIZE=30 class=box></TD></TR>
<TR>
<TD width=40% class=body><STRONG>Email ID</STRONG></TD>
<TD width=60% colspan=2><INPUT NAME="email" SIZE=30 class=lbox>
</TD>
</TR>
<TR>
<TD width=40% class=body><STRONG>Date of Birth</STRONG></TD>
<TD width=100><INPUT name=Dob size=30 class=box></TD>
<TD width=200 class=body><I>[dd-mm-yyyy]</I></TD>
</TR>
<TR>
<TD align=left>
<A href="javascript:history.back();"><img src="images/back.gif" border=0></A>
</TD>
<TD colspan=2>
<INPUT TYPE="button" NAME="sendit" VALUE="Send" onClick="javascript:check()">
</TD>
</TR>
</TABLE> </FORM>
</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

