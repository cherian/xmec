<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >></B> College</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top><BR>
  	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="mecnews.php#news14">Microsoft conducts <strong>.net</strong> Seminar in Model Engineering College</A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="mecnews.php#news13">Dr. Sukulal, the first principal of MEC passes away in a tragic accident.... </A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="mecnews.php#news12">Model Engineering College assigned specific Domain name for its site.. </A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="mecnews.php#news11">XMECians conduct Presentations in College on January 26<sup>th</sup> 2002.. </A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="mecnews.php#news10">Model Engineering College Magazine bags the coveted Manorama Award.. </A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="mecnews.php#news9">Model Engineering Students stand runners up in the Microsoft .NET Show... </A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="mecnews.php#news8">Dr K S M Panicker to join NSS College of Engineering, Palakkad... </A><BR><BR>
<BR><BR>
<IMG src="images/pen.gif"><A class=link href="addnews.php">Post a News items in the XMEC site ?</A>
<BR><BR>

<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news14">Microsoft conducts <strong>.net</strong> Seminar in Model Engineering College</A><BR>A talk was delivered by Mythreyee Ganapathy of Microsoft on August 12<sup>th</sup>, 2002. The talk covered cover the architecture of the .NET Framework and the components that make up the framework. While the .NET Framework is an excellent managed execution environment for enterprise development, it is also a great environment for component-based programming using object-oriented concepts.The talk focused on those<A href="http://www.mec.ac.in/events/dotnet.html" class=link> Aspects of the .NET Framework </A> that would facilitate teaching such concepts in Computer Science and Information Technology curricula. Mythreyee Ganapathy is the Product Manager, MS Visual Studio .NET, Redmond Campus, Washington, USA. <BR><BR><BR> <BR><A href="mecnews.php><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news13">Dr. Sukulal, the first principal of MEC passes away in a tragic accident....</A><BR>Dr. Sukulal, former principal of Model Engineering College met with tragic accident on the 4<sup>th</sup> of May, 2002. Dr. Sukulal was accompanied by Mr. Isahak Kurikal M.L.A&nbsp; when their car met with an accident at Peruthalmanna. Dr. Sukulal and Mr. Isahak&nbsp; were rushed to the hospital with serious head injuries. However he succumbed to his injuries on Monday 6<sup>th</sup> of May, 2002. His driver, Venugopalan too died in the accident. Dr. Sukulal was the principal of Model Engineering College during its formative years. He was on the way to attend a meeting in his official capacity as Director of IHRD when the tragic mishap occurred. The Alumni of Model Engineering College conveys its heartfelt condolences to the bereaved family on this grievous moment.<BR><A href="mecnews.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news12">Model Engineering College assigned specific Domain name for its site.. </A><BR>Model Engineering College is firmly placed in the wired world with the commencement of its own Domain in the internet. One can now access the college website at <A href="http://www.mec.ac.in" class=link>www.mec.ac.in</A>. Model Engineering college is now one of the few elite colleges which can boast of its own Domain. The college authorities are now in the process of setting up students specific mail servers apart from creating an informative website for the college. <BR><A href="mecnews.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news11">XMECians conduct Presentations in College on January 26<sup>th</sup> 2002.. </A><BR>The much delayed interaction between XMECians and students of the college was finally held on January 26<sup>th</sup>. XMECians visited the college and held presentations on <I>Current Scenario in the field of Information Technology</I>. They also made presentations on <I> The Job Opportunities that an Engineer can avail on Graduation </I>. There were interactive discussions on specific topics like <I>Venues for Higher studies, Hardware design, Software Design Process,</I> and <I>How to draft Impressive Resumes</I>. The students had specific queries on the various requirements with regard to GRE and MTech. The sessions by Renish Pynadath (EE 94-98) proved to be an eye opener for all. The students also enquired about the possibilities of any kind of association between companies and the College. They wanted to explore the possibility of companies assisting in setting up advanced Labs in niche` fields like DSP, Platform Development etc. <BR><A href="mecnews.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news10">Model Engineering College Magazine bags the coveted Manorama Award.. </A><BR>The College Magazine of Model Engineering College for the year 1999-2000&nbsp; <I>Thinking On Paper</I> was adjusted the Best College magazine from magazines from various colleges in Kerala. The panel of judges included imminent personlities like Anita Pratap and Mammen Mathew.<I> Thinking on Paper</I> was a clear winner all along, states Anita Pratap during a Press Release. George Mathew is the Chief Editor of the magazine. Read this on the <A href="http://www.malayalamanorama.com/02feb13/pictures.htm#4" class=link>Manorama</A> website. <I>Thinking on Paper</I> has also bagged the Runners up at the Matrubhumi Magazine Awards. <BR><A href="mecnews.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news9">Model Engineering Students stand runners up in the Microsoft .NET Show... </A><BR>Students from MEC brought laurels to the state when they finished runners up in the Microsoft Technical Fest. The event was held on a National level and served as a platform to showcase their latest offering in the world of IT called .NET <BR><A href="mecnews.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news8">Dr K S M Panicker to join NSS College of Engineering, Palakkad... </A><BR>Dr K S M Panicker has been appointed the Head of Electronics Department in NSS College of Engineering, Palakkad. After a distinguished career as Professor and Vice Principal, Dr.Panicker served as principal of MEC for the last five years. Prof. Jyothi John has been bestowed the responsibilities of principal henceforth. <BR><A href="mecnews.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
</P><BR>
  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

