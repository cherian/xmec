<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>Activities >></B> At College</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top><BR>
  	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="colact.php#news7">IEEE Chapter of MEC to organise EXCEL 2K3...</A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="colact.php#news6">XMECians to conduct a seminar on Higher Education in the USA...</A><BR><BR>
<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="colact.php#news5">MEC to conduct Training Programme on Linux/GNU...</A><BR><BR>
<IMG src="images/pen.gif"><A class=link href="addnews.php">Post a new Activity in the XMEC site ?</A>

<BR><BR>

<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news7">IEEE Chapter of MEC to organise EXCEL 2K3...</A><BR>The IEEE Chapter of MEC plans to organize the next edition of the <strong>Annual Technical Meet EXCEL 2K3 </strong>towards the first quarter of 2003. There are plans to ramp up the event into a South India Technical Event. While the ground work for the same have begun the right earnest, the event is tentatively planned for the 7<sup>th</sup> and 8<sup>th</sup> of March 2002. The Students Chapter of the IEEE requests the help and cooperation of all XMECians to make this a grand success. One can contact <A href="mailto:ieee@mec.ac.in?Subject=Details/Suggestions for EXCEL 2K3"class=link >Varghese Eapen, Chairman, IEEE Students Chapter MEC</A> for details.<BR><A href="colact.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news6">XMECians to conduct a seminar on Higher Education in the USA...</A><BR>There will be a seminar on <strong> Higher Studies in the USA</strong> to be held at Model Engineering College Campus on the 27<sup>th</sup> of December, 2002. The seminar will be followed by a talk on the <strong>MBA Institutes in India and Management Education in India</strong>. The intended audience for the same are the students of MEC. All faculty and XMECians are cordially invited to grace the occasion. The seminar is slated to begin at 10 am in the morning. The talk will be facilitated by XMECians. They include <A href="search.php?&name=joby++babu&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Joby Babu (EE 94-98)</A>, <A href="search.php?&name=praveen++g&worktype=&year=&company=&branch=&location=&.s=Search" class=link>Praveen Gopalakrishnan (EE 94-98)</A> and <A href="search.php?&name=renish++pynadath&worktype=&year=&company=&branch=&location=&.s=Search" class=link> Renish Pynadath (EE 94-98)</A>. <BR><A href="colact.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>
<HR width="100%" color="#dddddd">
<P class=body><IMG src="images/dot1.gif">&nbsp;&nbsp;<A name="news5">MEC to conduct Training Programme on Linux/GNU...</A><BR>Model Engineering College will conduct a short term training programme on <I>GNU/Linux Operating System and its Effective use in Computing Curricula</I>. The course is aimed
primarily at the Teaching faculty of Engineering Colleges. The course is sponsored by Indian Society for Technical Education and All India Council for Technical Education. The training programme will be held from the 5<sup>th</sup> of August to the 8<sup>th</sup> of August 2002. <A class=link href="mailto:jyothijohn@mec.ac.in">Prof. Jyothi John</A>, Principal and Head of the Department of Computer Engineering, Model Engineering College will be the course coordinator.<BR><A href="colact.php"><IMG align=right border=0 src="images/top.gif"></A> </P><BR>

  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>
