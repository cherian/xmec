<?php
	include_once 'xmec.inc';
		if (!XMEC::authenticate_user() && $secure_page) {
			global $PHP_SELF;
			$url = "login.php?xgetpage=$PHP_SELF";
			header("Location: $url");
			exit ;
		}
		function show_discussion() {
  echo '<TR>
  	<TD align=center height=3 background="images/hdot.gif"><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD align=center height=120><A href="/phorum/index.php"><img src="images/discussion.gif"  border=0></A></TD>
  </TR>';
}
function show_career() {
   echo '<TR>
  	<TD align=center height=3 background="images/hdot.gif"><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD height=134><A href="career.html"><img src="images/career.jpg" width=174 height=134 border=0></A></TD>
  </TR>';
	}
function show_gallery() {
   echo '<TR>
    <TD align=center height=3 background="images/hdot.gif"><img src="images/space.gif"></TD>
  </TR>
  <TR>
    <TD height=134><A href="career.html"><img src="images/galleria.gif" width=174
height=134 border=0></A></TD>
  </TR>';
  }

	$user = XMEC::getUser();
?>
<HTML>
<HEAD>
<TITLE>::: XMECians on the web!! :::</TITLE>
<style>
.linkh{FONT-SIZE: 10px;COLOR: #8EBBE6;LINE-HEIGHT: 130%;FONT-FAMILY: verdana,arial;TEXT-DECORATION: none;}
.linkh:hover{FONT-SIZE: 10px;COLOR: #FFFFFF;LINE-HEIGHT: 130%;FONT-FAMILY: verdana,arial;TEXT-DECORATION: none;}
</style>
<LINK href="style.css" type="text/css" rel="Stylesheet">
<?php if ($need_cal_js) {
echo '<SCRIPT language=JavaScript src="calendar.js" type=text/javascript></SCRIPT>';
} ?>
<script language="javascript">
function show(x)
{
	change();
	document["img"+x].src = "/images/"+x+"_on.gif";
	if (document.all)
		document.all["Layer"+x].style.visibility="visible";
	else if (document.layers) {
		document.layers["Layer"+x].visibility="visible";
	} else { // new w3c standard
		document.getElementById("Layer"+x).style.visibility = "visible";
	}
}
function change()
{
	if (document.all){
		for (var i = 1; i <=7; i++) { // IE 5 
			document["img"+i].src = "/images/"+i+"_off.gif";
			document.all["Layer"+i].style.visibility="hidden";
		}
	} else if (document.layers){ // Netscape 4
		for (var i = 1; i <=7; i++) {
			document["img"+i].src = "/images/"+i+"_off.gif";
			document.layers["Layer"+i].visibility="hidden";
		}
	} else {
	// For w3c Complaint browsers do the following after detecting them.
	// To check you can use any Gaecko based browsers. mozilla, galeon,
	// Firebird for example.
	// Also the positioning has been changed.
		for (var i = 1; i <=7; i++) {
			document["img"+i].src = "/images/"+i+"_off.gif";
			document.getElementById("Layer"+i).style.visibility="hidden";
		}
	}
}
</script>

</HEAD>
<BODY topmargin=0 leftmargin=0 rightmargin=0 marginheight="0" marginwidth="0">
<TABLE cellSpacing=0 cellPadding=0 width=780 border=0 bgcolor="#FFFFFF">
  <TR>
<TD colspan=7 height=73 background="images/topback.jpg" valign=bottom><A name="top"><img src="images/logo.gif" width=520 height=53 usemap="#XMEC" border=0></A></TD>
  </TR>
  <TR>
    <TD colspan=7 height=1 bgcolor="#FFFFFF"><img src="images/space.gif"></TD>
  </TR>
<!--first menu starts-->
  <TR>
    <TD width=35 height=20 bgcolor="#8EBBE6"><img src="images/space.gif"></TD>
    <TD height=20 colspan=5 bgcolor="#8EBBE6" align=left valign=bottom>
<TABLE cellSpacing=0 cellPadding=0 bgcolor="#8EBBE6" align=left border=0>
  <TR>
    <TD><A href="javascript:show('1')" onClick="javascript:show('1')"><img src="images/1_off.gif" name=img1 border=0></A></TD>
    <TD><A href="/vision.php" onClick="javascript:show('2')"><img src="images/2_off.gif" name=img2 border=0></A></TD>
    <TD><A href="javascript:show('3')" onClick="javascript:show('3')"><img src="images/3_off.gif" name=img3 border=0></A></TD>
    <TD><A href="javascript:show('4')" onClick="javascript:show('4')"><img src="images/4_off.gif" name=img4 border=0></A></TD>
    <TD><A href="javascript:show('5')" onClick="javascript:show('5')"><img src="images/5_off.gif" name=img5 border=0></A></TD>
    <TD><A href="javascript:show('6')" onClick="javascript:show('6')"><img src="images/6_off.gif" name=img6 border=0></A></TD>
    <TD><A href="javascript:show('7')" onClick="javascript:show('7')"><img src="images/7_off.gif" name=img7 border=0></A></TD>
  </TR>
</TABLE>
    </TD>
    <TD width=35 height=20 bgcolor="#8EBBE6"><img src="images/space.gif"></TD>
  </TR>
<!--first menu ends-->
<!--second menu starts-->
  <TR>
    <TD width=35 colspan=7 height=18 bgcolor="#0958A3"><img src="images/space.gif"></TD>
  </TR>
<!--second menu ends-->
  <TR>
    <TD rowspan=3 width=35 bgcolor="#E6EBEF"><img src="images/space.gif" width=35></TD>
    <TD rowspan=3 width=1 bgcolor="#FF6666"><img src="images/space.gif"></TD>
    <TD colspan=3 height=26 width=708 align=right>
		<TABLE cellSpacing=0 cellPadding=0 width=700 height=26 border=0 bgcolor="#FFFFFF">
		  <TR>
			<?php $user =& XMEC::getUser();
				if ($user->isLoggedIn()):  ?>
				<TD width=570 class=body>Welcome <b class=name>
			<?php echo $user->get('first_name')." ".$user->get('middle_name')." ".$user->get('last_name') ?>
				</b></TD>
				<TD align=right width=70><A href="/login.php?action=logout"><img src="images/logoff.gif" border=0 align=right></A></TD>
			<? else: ?>
				<TD width=570 class=body>Welcome</TD>
				<TD align=right width=70><A href="login.php"><img src="images/login.gif" border=0 align=right></A></TD>
			<? endif ?>
		  	<TD align=right width=60 nowrap><A href="/index.php"><img src="images/home.gif" border=0 align=right></A></TD>
		  </TR>
		</TABLE>
    </TD>
    <TD rowspan=3 width=1  bgcolor="#FF6666"><img src="images/space.gif"></TD>
    <TD rowspan=3 width=35 bgcolor="#E6EBEF"><img src="images/space.gif" width=35></TD>
  </TR>
  <TR>
    <TD colspan=3 height=1 width=708 bgcolor="#DBDBDB"><img src="images/space.gif"></TD>
  </TR>
  <TR>
<? if (!$no_left_side) { ?>
<!--left side starts-->
    <TD width=174 valign=top>
<TABLE cellSpacing=0 cellPadding=0 width=174 border=0 bgcolor="#FFFFFF">
	<?php 
# Put the rows for showing the discussion
if (($this_page == 'news') || ($this_page == 'poll')) {
show_discussion();
} ?>
	<?php 
# Put the rows for showing career 
if (($this_page == 'xmec') || ($this_page == 'poll')) {
show_career();
} ?>
  <?php
# Put the rows for showing gallery
if (($this_page == 'xmec') || ($this_page == 'poll')) {
show_gallery();
} ?>

 <TR>
  	<TD align=center height=3 background="images/hdot.gif"><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD align=center>
<?  if (!$no_search_menu) {   ?>
<!--XMECian search starts-->
<TABLE cellSpacing=2 height=100 cellPadding=0 border=0>
<FORM name=frmxsearch method=get action="/search.php">
  <TR>
  	<TD colspan=3 align=center height=20><img src="images/xsearch.gif" width=151 height=12></TD>
  </TR>
  <TR>
  	<TD><img src="images/name.gif" width=34 height=10></TD>
  	<TD align=right><INPUT name=name type=text class=box size=10></TD>
  	<TD><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD><img src="images/place.gif" width=34 height=10></TD>
  	<TD align=right><INPUT name=location type=text class=box size=10></TD>
  	<TD><INPUT name=b type=image src="images/go.gif" border=0 width=15 height=15></TD>
  </TR>
  <TR>
  	<TD colspan=3 align=center height=20><A href="/search.php"><img src="images/adsearch.gif" width=156 height=11 border=0></A></TD>
  </TR>
	<INPUT TYPE=HIDDEN NAME=".s" VALUE="Search">
</FORM> 
</TABLE>
<?  }  ?>
<!--XMECian search ends-->  	
   	</TD>
  </TR>
</TABLE>
<!--left side ends-->
    </TD>
    <TD width=1 bgcolor="#FF6666"><img src="images/space.gif"></TD>
    <TD width=533 valign=top>
<? } else { ?>
    <TD width=700 valign=top>
<? } ?>
<div id="Layer1"  style="position:absolute; visibility: hidden; top:94px; left:40px;">
<TABLE width=250 cellSpacing=1 cellPadding=1 border=0>
  <TR>
    <TD><A href="/xmec.php" class=linkh>Xmec</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/college.php" class=linkh>College</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/university.php" class=linkh>University</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/contact.php" class=linkh>Contact Us</A></TD>
  </TR>
</TABLE>
</div>
<div id="Layer2"  style="position:absolute; visibility: hidden; top:94px; left:40px;">
</div>
<div id="Layer3"  style="position:absolute; visibility: hidden; top:94px; left:160px;">
<TABLE width=110 cellSpacing=1 cellPadding=1 border=0>
  <TR>
    <TD><A href="/search.php" class=linkh>Search</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/groups.php" class=linkh>Groups</A></TD>
		<?php if ($user->isAdmin()) { ?>
    <TD class=linkh>|</TD>
    <TD><A href="/admin.php" class=linkh>Administration</A></TD>
		<? } ?>
  </TR>
</TABLE>
<!-- /TABLE is this the probs Pash -->
</div>
<div id="Layer4"  style="position:absolute; visibility: hidden; top:94px; left:235px;">
<TABLE width=170 cellSpacing=1 cellPadding=1 border=0>
  <TR>
    <TD><A href="/xnews.php" class=linkh>XMEC</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/mecnews.php" class=linkh>College</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/letters.php" class=linkh>Letters</A></TD>
  </TR>
</TABLE>
</div>
<div id="Layer5"  style="position:absolute; visibility: hidden; top:94px; left:285px;">
<TABLE width=170 cellSpacing=1 cellPadding=1 border=0>
  <TR>
    <TD><A href="/colact.php" class=linkh>College</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/chapters.php" class=linkh>Chapters</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/careers.php" class=linkh>Careers</A></TD>
  </TR>
</TABLE>
</div>
<div id="Layer6"  style="position:absolute; visibility: hidden; top:94px; left:355px;">
<TABLE width=95 cellSpacing=1 cellPadding=1 border=0>
  <TR>
    <TD><A href="/gallery.php" class=linkh>Gallery</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/video.php" class=linkh>Video</A></TD>
  </TR>
</TABLE>
</div>
<div id="Layer7"  style="position:absolute; visibility: hidden; top:94px; left:280px;">
<TABLE width=475 cellSpacing=1 cellPadding=1 border=0>
  <TR>
    <TD><A href="/calendar.php" class=linkh>Calender</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/post_job.php" class=linkh>Post a Job</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/phorum/index.php" class=linkh>Discussions</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/polls.php" class=linkh>Polls</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/accounts.php" class=linkh>Accounts</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/editprofile.php" class=linkh>My Profile</A></TD>
    <TD class=linkh>|</TD>
    <TD><A href="/preferences.php" class=linkh>My Preferences</A></TD>
  </TR>
</TABLE>
</div> 
