<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>Activities >></B>XMEC Chapters</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="chapters.php#news1">College Chapter </A><BR><BR>
	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="chapters.php#news2">Bangalore Chapter </A><BR><BR>
	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="chapters.php#news3">Chennai Chapter </A><BR><BR>
	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="chapters.php#news4">Hyderabad Chapter </A><BR><BR>
	
	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="chapters.php#news5">USA East Coast Chapter </A><BR><BR>
	<IMG src="images/dot.gif">&nbsp;&nbsp;<A class=link href="chapters.php#news6">US West Coast Chapter </A><BR><BR>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433>
<IMG src="images/dot1.gif">&nbsp;&nbsp;<A class=link name="news1"><strong>College Chapter.</strong></A>
<HR width=433 color=#dddddd>
<P class=body>The College chapter comprises all the XMECians who work and live in Kerala. All XMECians working at Model Engineering College, in Kochi, Thiruvanathapuram and other cities of Kerala are part of this chapter. The Principal and College faculty are members of this Chapter. This Chapter controls and accounts the current funds of XMEC </P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=143><P class=body><strong>Chapter Strength : 30 </strong></P></TD>
<TD bgcolor="#dddddd" width=290>
	<P class=body><strong>Executive Committee </strong>
	<UL><LI class=body>President: VidhiPrasad (1st batch)
        <LI class=body>Vice President:Jithesh (4th batch)
 	<LI class=body>Secretary: Mohammed Sageer (7th batch)
        <LI class=body>Joint Secretary:Abdul Rasheed (8th batch)
        <LI class=body>Treasurer: Vijayalakshmi (1st batch)</LI>
	</UL>
                  
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="chapters.php"><IMG align=right border=0 src="images/top.gif"></A>

<BR><BR>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433>

<IMG src="images/dot1.gif">&nbsp;&nbsp;<A class=link name="news2"><strong>Bangalore Chapter </strong></A>
<HR width=433 color=#dddddd>
<P class=body>Bangalore chapter comprises all the XMECians who work and live in Bangalore and other important cities in Karnataka like Mysore and Mangalore. It is the single largest chapter in terms of number of active XMECians. </P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=143><P class=body><strong>Chapter Strength : 240 </strong></P></TD>
<TD bgcolor="#dddddd" width=290>
	<P class=body><strong>Working Committee </strong>
	<UL><LI class=body>Manu Sreenivasan (1st batch) 
                    
	<LI class=body>Rajesh Bhaskar (4th batch) 
                    
	<LI class=body>Anoop A (5th batch) 
                    
	<LI class=body>Renish Pynadath (6th batch) 
                    
	<LI class=body>Rathish Chandran (7th batch) 
                    
	<LI class=body>Krishnan B (8th batch) 
        <LI class=body>Sameer Elachola (9th batch) </LI>
        <LI class=body>Abdul Rafeeq (10th batch) </LI>
				<LI class=body>Arun P R (11th batch) </LI>


	</UL>
                  
</TD>
</TR>
</TABLE>

	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>

<A href="chapters.php"><IMG align=right border=0 src="images/top.gif"></A><BR><BR>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433>

<IMG src="images/dot1.gif">&nbsp;&nbsp;<A class=link name="news3"><strong>Chennai Chapter </strong></A>
<HR width=433 color=#dddddd>
<P class=body>Chennai chapter comprises all the XMECians who work and live in Chennai and other parts of Tamil Nadu. It is the only XMEC chapter active in any Metropolitan city in India. </P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=143><P class=body><strong>Chapter Strength : 30 </strong></P></TD>
<TD bgcolor="#dddddd" width=290>
	<P class=body><strong>Working Committee </strong>
	<UL><LI class=body>Prinu Shaan Nazeem (6th batch) 
   	<LI class=body>Lima Iype(7th batch) 
	</UL>
                  
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="chapters.php"><IMG align=right border=0 src="images/top.gif"></A><BR><BR>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
  <TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
  <TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
  <TD width=433>

<IMG src="images/dot1.gif">&nbsp;&nbsp;<A class=link name="news4"><strong>Hyderabad Chapter </strong></A>
<HR width=433 color=#dddddd>
<P class=body>Hyderabad chapter comprises all the XMECians who work and live in Hyderabad and other parts of Andhra Pradesh. It is the latest chapter to be created in the alumni. </P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=143><P class=body><strong>Chapter Strength : 30 </strong></P></TD>
<TD bgcolor="#dddddd" width=290>
  <P class=body><strong>Working Committee </strong>
  <UL><LI class=body>Prinu Shaan Nazeem (6th batch)
    <LI class=body>Lima Iype(7th batch)
    <LI class=body>Rahulan A M (8th batch) </LI>
  </UL>

</TD>
</TR>
</TABLE>
  </TD>
  <TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
  <TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>

<A href="chapters.php"><IMG align=right border=0 src="images/top.gif"></A><BR><BR>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433>

<IMG src="images/dot1.gif">&nbsp;&nbsp;<A class=link name="news5"><strong>US East Coast Chapter </strong></A>
<HR width=433 color=#dddddd>
<P class=body>US East Coast comprises of the region predominantly in the Eastern Standard Time zone from Boston to Kentucky with the majority of XMECians concentrated in Maryland, Virginia, Boston and New Jersey </P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=143><P class=body><strong>Chapter Strength : 35 </strong></P></TD>
<TD bgcolor="#dddddd" width=290>
	<P class=body><strong>Working Committee </strong>
	<UL><LI class=body>To be Nominated </LI>
	</UL>
                  
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="chapters.php"><IMG align=right border=0 src="images/top.gif"></A><BR><BR>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=433>

<IMG src="images/dot1.gif">&nbsp;&nbsp;<A class=link name="news6"><strong>US West Coast Chapter </strong></A>
<HR width=433 color=#dddddd>
<P class=body>US West Coast comprises of the region predominantly in the Western Standard Time zone with the majority of XMECians concentrated in the Bay Area in and around Silicon Valley </P>

<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD bgcolor="#dddddd" width=143><P class=body><strong>Chapter Strength : 51 </strong></P></TD>
<TD bgcolor="#dddddd" width=290>
	<P class=body><strong>Working Committee </strong>
	<ULclass=body><LI class=body>Abhilash P.P (1st batch) 
                    
	<LI class=body>Joby T.S (2nd batch) 
                    
	<LI class=body>Manohar Chandrashekhar (3rd batch) 
                    
	<LI class=body>Faisal P A (4th batch) 
                    
	<LI class=body>Arvind Bhat (5th batch) 
                    
	<LI class=body>Shanavaz V K (7th batch) </LI></UL>
                  
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="chapters.php"><IMG align=right border=0 src="images/top.gif"></A><BR><BR></TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>`
