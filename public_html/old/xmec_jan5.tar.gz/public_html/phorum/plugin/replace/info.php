<?php

$pluginname = "replace";
$plugindesc = "simple text replacment plugin";
$pluginversion = "0.1";

?>