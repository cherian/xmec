<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>XMECian >></B> Groups & Mailing Lists</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
<script language="javascript" src="jslibxmec.js">
</script>
<script language="javascript">
function check()
{

  if (false == validate())
  {
     return;
   }
   else
   document.emails.submit();
   
 }   
function validate()
{
	if (document.emails.list.options[document.emails.list.selectedIndex].value == ""){ 
	alert("Please Select the Batch");
	return false;
	}
	if (document.emails.sub.value == ""){ 
	alert("Please enter the Subject");
	return false;
	}	
	if(!CheckEmailStr(document.emails.email.value )){
//	alert("Please Please verify Personel Email");
	return false;
	}
	if (document.emails.information.value == ""){ 
	alert("Please enter the Message");
	return false;
	}	
		return true;
	}

function canceltext()
{ 
document.emails.information.value = "";
}

function displayinfo(){
        var who=document.emails.list.options[document.emails.list.selectedIndex].value;
//        var address=document.emails.address;
        var info=document.emails.information;
        
if (who==""){
                info.value="Please select the group you want to send the message.";}
if (who=="xmec"){
                info.value="This message will be conveyed to all XMECians on approval of the moderator.";
                document.emails.recipient.value = "xmec-owner@yahoogroups.com";
                }
if (who=="xmec_e"){
                info.value="This message will be conveyed to all XMECians of US East Coast on approval of the moderator.";
                document.emails.recipient.value = "xmec_east-owner@yahoogroups.com";
                }
if (who=="xmec_w"){
                info.value="This message will be conveyed to all XMECians of US West Coast on approval of the moderator.";
                document.emails.recipient.value = "xmec_west-owner@yahoogroups.com";
                }
if (who=="batch1"){
                info.value="This message will be conveyed to all XMECians of First Batch on approval of the moderator.";
                document.emails.recipient.value = "mecbiomedical89-owner@yahoogroups.com ";
                }
if (who=="batch2"){
                info.value="This message will be conveyed to all XMECians of Second Batch on approval of the moderator.";
                document.emails.recipient.value = "ce90-owner@yahoogroups.com";
                }
if (who=="batch3"){
                info.value="This message will be conveyed to all XMECians of Third Batch on approval of the moderator.";
                document.emails.recipient.value = "robi_thomas@mindtree.com";
                }
if (who=="batch4"){
                info.value="This message will be conveyed to all XMECians of Fourth Batch on approval of the moderator.";
                document.emails.recipient.value = "ee92-96-owner@yahoogroups.com,ce92-owner@yahoogroups.com";
                }
if (who=="batch5"){
                info.value="This message will be conveyed to all XMECians of Fifth Batch on approval of the moderator.";
                document.emails.recipient.value = "a.anoop@blr.spcnl.co.in, 9397-owner@yahoogroups.com, ryaaz.soofi@wipro.com ";
                }
if (who=="batch6"){
                info.value="This message will be conveyed to all XMECians of Sixth Batch on approval of the moderator.";
                document.emails.recipient.value = "ee94mec-owner@yahoogroups.com, ce94mec-owner@yahoogroups.com, be94mec-owner@yahoogroups.com";
                }
if (who=="batch7"){
                info.value="This message will be conveyed to all XMECians of Seventh Batch on approval of the moderator.";
                document.emails.recipient.value = "mec95-owner@yahoogroups.com";
                }
if (who=="batch8"){
                info.value="This message will be conveyed to all XMECians of Eighth Batch on approval of the moderator.";
                document.emails.recipient.value = "mec2k-owner@yahoogroups.com";
                }
if (who=="batch9"){
                info.value="This message will be conveyed to all XMECians of Ninth Batch on approval of the moderator.";
                document.emails.recipient.value = "mecee2001-owner@yahoogroups.com, c2k1mec-owner@yahoogroups.com, royalbios2k1-owner@yahoogroups.com, CHHORRIPARRI@yahoogroups.com";
                }
if (who=="batch10"){
                info.value="This message will be conveyed to all XMECians of Tenth Batch on approval of the moderator.";
                document.emails.recipient.value = "mec2k2@yahoogroups.com";
                }

}


</script>
<FORM name="emails" method="post" action="../cgi-bin/FormMail.pl">
<INPUT TYPE="hidden" NAME="recipient" value="">
<INPUT TYPE="hidden" NAME="subject" VALUE="Message to Yahoogroups - www.xmec.net">
<INPUT TYPE="hidden" NAME="redirect" VALUE="http://www.xmec.net/thankyou.html">

<TABLE BORDER=0 cellpadding=5 cellspacing=0 bordercolor="#dddddd" WIDTH="425">
<TR><BR><BR>
<TD width=150 class=body><B>Batch</B></TD>
<TD width=275><SELECT NAME="list" onChange="displayinfo()" class=cbox >
<OPTION value="" 
              selected>Select One</OPTION>
<OPTION value="xmec">XMEC</OPTION>
<OPTION value="xmec_e">XMEC - US East Coast</OPTION>^M
<OPTION value="xmec_w">XMEC - US West Coast</OPTION>^M
<OPTION value="batch1">1st Batch (89-93)</OPTION>
<OPTION value="batch2">2nd Batch (90-94)</OPTION>
<OPTION value="batch3">3rd Batch (91-95)</OPTION>
<OPTION value="batch4">4th Batch (92-96)</OPTION>
<OPTION value="batch5">5th Batch (93-97)</OPTION>
<OPTION value="batch6">6th Batch (94-98)</OPTION>
<OPTION value="batch7">7th Batch (95-99)</OPTION>
<OPTION value="batch8">8th Batch (96-00)</OPTION>
<OPTION value="batch9">9th Batch (97-01)</OPTION>
<OPTION value="batch10">10th Batch (98-02)</OPTION>
</SELECT></TD>
</TR>
<TR>
<TD width=150 class=body><B>Subject</B></TD>
<TD width=275><INPUT NAME="sub" type=text class=box size=10>
</TD></TR>
<TR>
<TD width=150 class=body><B>Your Email ID</B></TD>
<TD width=275><INPUT NAME="email" type=text class=box size=10>
</TD></TR>
<TR><TD colspan=2><TEXTAREA class=tbox cols=50 name=information rows=10 wrap=virtual onfocus="javascript:canceltext();">Please select the group you want to send the message</TEXTAREA>
</TD></TR>
<TR><TD align=middle colspan=2>
<INPUT TYPE="Button" NAME="sendit" VALUE="Send" onclick="javascript:check();">
</TD>
</TR>
</TABLE> </FORM>

  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
include 'footer.php';
?>

