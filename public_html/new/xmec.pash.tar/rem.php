<?php
$secure_page=0;
include 'header.php';
?>
<!--center starts-->
<TABLE cellSpacing=0 cellPadding=1 width=527 border=0>
  <TR>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  	<TD width=477 height=40 class=head><B>News >> <A HREF="letters.php" class=link>Letters</A> >>
</B>Remembering Dr. Sukulal</TD>
  	<TD width=25 rowspan=2><img src="images/space.gif"></TD>
  </TR>
  <TR>
  	<TD width=477 valign=top>
  	<P class=body><IMG src="images/dr_sukulal.jpg" width=100 height=160 align=left>XMECians remember with utmost humility, the great contributions made by Dr. Sukulal in their lives. We hope and pray that the Almighty consoles and comforts his family at this moment of tragedy. Some have penned a few words, an expression of the sorrow and deep love for the towering personality he was</P><BR><BR><BR><BR>
</TD>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=425 class=body>
<IMG src="images/pen.gif">&nbsp;&nbsp;<strong>..All our prayers are with him...</strong>
<HR width=433 color=#dddddd>
<P class=body><i>I belonged to the first batch of students at MEC. It is with utmost shock and sadness that all of us are hearing the news about Sukulal sir's demise. He always has a special place in all our minds.</i></P>
<P class=body><i>The first few batches interacted with him a lot when he was the Principal. It will be an understatement if I say MEC is what it is today because of his efforts. He managed it right and hired the right people to run the college. Some of us in the first batch were even fortunate enough to be his students. He taught us Basic Electronics in the first semester.</i></P>
<P class=body><i>I know I wouldn't be here without his help. And I am sure there are a lot of people who feel that way. All our prayers are with him. He was a truly remarkable individual.</i></P>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD width=290><P class=body><i>Palo Alto<BR>May 6<sup>th</sup> 2002</i></P></TD>
<TD width=100><P class=body><i>Subramoniam N.<BR>CE 45/89</i></P>
</TD>
</TR>
</TABLE>
	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>
</TR>
</TABLE><BR>
<A href="rem.php"><IMG align=right border=0 src="images/top.gif"></A>

<BR><BR>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="445">
<TR>
	<TD colspan=3><IMG src="images/tabletop.gif"></TD>
</TR>
<TR>
	<TD width=6 background="images/tableleft.gif"><IMG src="images/tableleft.gif"></TD>
	<TD width=425 class=body>

<IMG src="images/pen.gif">&nbsp;&nbsp;<strong>...He made me what I am today...</strong>
<HR width=433 color=#dddddd>
<P class=body><i>Dr. Sukulal must have inspired hundreds of aspiring young engineers. I am one of them. Now, grief  is total. Reality is harsh. I had a lot to tell him when we met again. Now the wait will have to be longer...</i></P>
<P class=body><i>A dedicated team built a temple of knowledge with determination. Dr. Sukulal lead&nbsp;from the front, and Model Engineering College became a reality. The engineer in me and hundreds of others became a reality. The college indeed is "model" in many respects. I will not go into any details. It is not required. Fate endowed the fortune on me and a few others to be part of the first batch of students to have worked hand in hand with Dr.Sukulal and his team to carve the destiny of MEC right from inception. Rome was not built in a day. Neither was MEC. Many others followed to take up the mantle and build it higher. MEC's alumni is a force to reckon with in the technology driven world today. A great achievement by any standards to have done it in around a decade.</i></P>
<P class=body><i>The personal effort and pains taken by Dr. Sukulal was the source of inspiration and confidence for the team during the trying periods of infancy. We still see it as a miracle to have actually spend our last year of B.Tech in the enviable new campus and buildings of MEC. A miracle that was realised in a land where mis-management, inefficiency, irresponsibility and corruption were taken for granted as a way of life. Dr. Sukulal proved that you can build positive cultures if you want to.</i></P>
<P class=body><i>I am trying to follow his foot steps. I am also laying the foundations of a similar organization breeding a positive, responsible and sensitive work culture. I am sure that I am only one in the crowd out there, working to make the world a better place as Dr. Sukulal defined the role of an engineer - "Make technology work to improve the standard of living for the common man".  There lies the greatness of this man - He has left behind a legacy to carry on the work he started. It does not stop with him. That is the nature of a visionary. That is the hall mark of a selfless crusader.</i></P>
<P class=body><i> part of me has left me. This has happened before. This will happen again. But each time it is new. This time it is a force whose existence was a comfort when I had to take bold decisions that has silently departed into the "prakrithi". I vividly remember introducing Dr.Sukulal to my ex-colleagues from ER&DC on the occasion of my sister's wedding an year back- "My Guru; He made me what I am today..."</i></P>
<P class=body><i>My guru has left me. Our guru has left us..."</i></P>
<TABLE border=0 cellPadding=5 cellSpacing=1 width="433">
<TR>
<TD width=200><P class=body><i>Bangalore</i></BR><i>May 9<sup>th</sup> 2002</i></P></TD>
<TD  width=150>
	<P class=body><i>Sreeraj S</i><BR><i>EE 1/89</i><BR><i>Chief Technical Officer</i><BR><i>Ordyn Electronic Systems</i></P>
</TD>
</TR>
</TABLE>

	</TD>
	<TD width=6 background="images/tableright.gif"><IMG src="images/tableright.gif"></TD>
</TR>
<TR>
	<TD colspan=3><IMG src="images/tablebottom.gif"></TD>



  	</TD>
  </TR>
</TABLE>
<!--center ends-->
<?php
$secure_page=0;
include 'footer.php';
?>
