<html>
	<head>
		<title>
			Anyform Processing with PHP
		</title>

	</head>
<link href="./vt.css" rel="stylesheet" type="text/css">

<body leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0">

<table width="750" border="0" cellspacing="0" cellpadding="5">
	<tr> 
		<td height="60" colspan="3">
			Heading or logo
		</td>
	</tr>
	<tr> 
		<td height="60" colspan="3">
			<span class="title"><center>Anyform Processing with PHP.</center></span>
		</td>
	</tr>
	<tr> 
		<td height="60" colspan="3">
			Sub heading
		</td>
	</tr>
	<tr> 
		<td width="100" rowspan="2" valign="top"> <span class="standardtext">
		Side column
	 	<td width="490" valign="top"><div align="left" class="smallfont2">
			<p align="left">

<?PHP

/*
This is just a simple PHP form processing script, that people may or MAY NOT find useful.
It is intended for intergrating an upload option into any PHP script; simply cut and paste
this code into the form processing part of your script. 
You could add some header HTML above the <?PHP tag and some footer HTML below the last?> tag
to use this as a stand alone upload script. The form tag would need to be 
<form method="POST" action="PATH-TO/anyform.php" enctype="multipart/form-data">

All field values are placed in the field name variable. i.e. the field value of 
<input type="text" name="TextFeildName"> 
will be stored in $TextFeildName

This is the first version, so send any feedback you have that would make the script more user friendly.

*/
$MD='./gallery/'; // Path to the upload directory: Default is the script directory
$MDurl='./gallery/'; //URL to the upload directory: Default is the script directory
$exten=' .jpg .gif .txt .png .bmp';// Type of image extensions allowed
// 1= ON, 0 = OFF
$show_when_upload_link=1; // Show uploaded file as a text link
$show_when_upload_image=1;// Show uploaded file as an image link
$show_upload_status=1; // Show uploaded file status i.e. "No file entered in field X";
$show_upload_status_errors=1; // Show reason if file upload fails
$show_when_upload_image_as_thumb=1;// if Jpg or Png show image as thumbnail, requires $show_when_upload_image=1;
$show_text_fields=1;// show the form names and values of any other fields

// That's is ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$IMAGE=0;
/*
Anyform PHP form processing script By www.VirtualThoughts.co.uk
If you use this script please leave the above credit.
*/
while(list($k,$val)= each($_POST)){ 
// go through all the posted variables and assign the values to the field name
$postnames[]=$k;// store the field names in an array
${$k}=$val;

}


$remember_place=0;
$success=0;
while(list($key,$v)= each($_FILES)){ 
// go through all the upload fields
	$file_name = $_FILES[$key]['name'];// assign the file name to a variable.
	$true_name = str_replace(" ","_",$file_name);// change spaces to _.
	$file_name = str_replace("%20","",$true_name);// change URL encoded space to nospace.

	if($_FILES[$key]['error']==0){// If file status is 0 the file has been uploaded
	
			$dot_is = strrpos("$file_name",'.');//find the last . in the file name
			$ext = substr("$file_name", $dot_is);// extract everthing from the dot to the eof and place in $ext
		 
		if($ext !='' AND preg_match("/$ext/i",$exten)){// if it has an extension and the ext is found in $exten .... cont.
			// Below is the normal upload processing line I prefer the other method.
			//if (move_uploaded_file($_FILES[$key]['tmp_name'], "$MD$file_name")) {
			if (is_uploaded_file($_FILES[$key]['tmp_name'])){ //Check the file was uploaded to the temp dir by a POST action
           		copy($_FILES[$key]['tmp_name'],"$MD$file_name");// copy the temp file to $MD and rename to $filename
           		unlink($_FILES[$key]['tmp_name']);// delete the temp file
        
			
				$success++;
				list($width,$heigth,$type,$attr)=getimagesize("$MD$file_name");// A bit of overkill to check the file type
								
					if($type>0 and $type<17){
						$IMAGE=1;// if file type returns a image set $IMAGE to 1
					}
					if($show_when_upload_link){// Display uploaded file as a test link
						 print "<a href='$MDurl$file_name' target='_blank'>$file_name</a><br>";
					}
					if($show_when_upload_image AND $IMAGE AND preg_match("/image\/([\w-]+)/i",$_FILES[$key]['type'],$regs)){
							//IF $show_when_upload_image and $IMAGE is true and double check file type is an image and store image type in $regs[1]
						if($show_when_upload_image_as_thumb AND $IMAGE  AND preg_match("/p?jpe?g|x-png/i",$regs[1])){
							// if condictions are true and $reg[1] is a jpg or png then display as thumb
					 		print "<a href='$MDurl$file_name' target='_blank'><img src='thumbnail.php?gdoption=thumb&src=$MDurl$file_name&maxw=125'></a><br>";
						}else{// else display as fake thumb (width='125'
					 		print "<a href='$MDurl$file_name' target='_blank'><img src='$MDurl$file_name' width='125'></a><br>";
				
						}//end if thumb
					}//end of display options
			  //$file_data[] = "$file_name:$file_caption";
			}//END did it upload
			 else {
  			  print "Possible file upload attack!\n<br>";// Diplay warning if anything wierd happens
			}// end if else uploaded

		}// end if file extenstion is found in $exten in config.php
		else{
		    print "$key $ext Bad extention, file not uploaded.<br>";// display error is extension is not in $exten
		}
	}// end if file upload error == 0
	else{
		if($show_upload_status_errors){ //Else if $_FILES[$key]['error'] !=0 and  if $show_upload_status_errors is true 
				switch ($_FILES[$key]['error']){// Display reason for failed upload

					case 1: print "$key: The uploaded file exceeds the upload_max_filesize directive in php.ini. THIS IS SERVER SIDE.<br>";break;
					case 2: print "$key: The uploaded file exceeds the MAX_FILE_SIZE directive that was specified by the site administrator.<br>";break;
					case 3: print "$key: The uploaded file was only partially uploaded.<br>";break;
					case 4: print "$key: No file was entered.<br><br>"; break;
					default: print "$key: Unknown upload Error!<br>";break;
					
				}//end switch
			}// end $show_upload_status
		}//end else show error ir upload error !=0
$remember_place++;
}// end $files while loop

if(!$success){// if $success is fales (=0) display no files uploaded

	print "No files uploaded!<br>";

}

if($show_text_fields){// if $show_text_fields is true (>0) run throught the array postnames and display the field name and values.
	if(isset($postnames)){
		for($i=0;$i < count($postnames);$i++){
			if(isset(${$postnames[$i]}) AND ${$postnames[$i]} !=''){$data=stripslashes(${$postnames[$i]});}else{$data='Blank!';}
			print "Field $i:".$postnames[$i].' was '.$data.'<br><br>';

		}
	}

}

?>

      </td>
    </tr>  
	</table></p>
</body>

</html>
